package com.calyrsoft.ucbp1.features.dollar.domain.model

data class Dollar(
    val value: Float,
    val lastUpdated: String = ""
)