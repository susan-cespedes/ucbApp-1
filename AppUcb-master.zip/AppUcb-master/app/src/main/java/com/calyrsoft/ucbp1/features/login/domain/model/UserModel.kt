package com.calyrsoft.ucbp1.features.login.domain.model

data class UserModel(val nickname: String, val pass: String)
